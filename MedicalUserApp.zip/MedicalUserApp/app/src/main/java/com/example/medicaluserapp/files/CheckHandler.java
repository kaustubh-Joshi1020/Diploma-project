package com.example.medicaluserapp.files;

import android.util.Log;
import android.widget.EditText;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CheckHandler {
    public static boolean checkAll(EditText[] all,String[] Message,String[] Validation,String[] VMessage) {
        boolean b1 = true;
        int Len = all.length;
        for(int a = 0;a<Len;a++)
        {
            if(all[a].getText().toString().equals(""))
            {
                all[a].setError(Message[a]);
                b1 = false;
            }
            switch (Validation[a]) {
                case "MOBILE":
                    if (!isMobileValid(all[a].getText().toString())) {
                        all[a].setError(VMessage[a]);
                        b1 = false;
                    }
                    break;
                case "EMAIL":
                    if (!isEmailValid(all[a].getText().toString())) {
                        all[a].setError(VMessage[a]);
                        b1 = false;
                    }
                    break;
                case "VEHICLE":
                    if (!isVehicle(all[a].getText().toString())) {
                        all[a].setError(VMessage[a]);
                        b1 = false;
                    }
                    break;
                default:
                    Log.d("CHECK_HANDLER","No Any Validation");
            }
        }
        return b1;
    }
    private static boolean isMobileValid(String number) {
        boolean check = false;
        String no = "[7-9]{1}[0-9]{9}";
        Pattern pte = Pattern.compile(no,Pattern.CASE_INSENSITIVE);
        Matcher matcher = pte.matcher(number);
        if(matcher.matches())
        {
            check = true;
        }
        return check;
    }
    private static boolean isVehicle(String number) {
        boolean check = false;
        String no = "[a-z]{2}[0-9]{1,2}[a-z]{2,3}[a-z0-9]{4}";
        Pattern pte = Pattern.compile(no,Pattern.CASE_INSENSITIVE);
        Matcher matcher = pte.matcher(number);
        if(matcher.matches())
        {
            check = true;
        }
        return check;
    }
    private static boolean isEmailValid(String email) {
        boolean check = false;
        String no = "[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}$";
        Pattern pte = Pattern.compile(no,Pattern.CASE_INSENSITIVE);
        Matcher matcher = pte.matcher(email);
        if(matcher.matches())
        {
            check = true;
        }
        return check;
    }
}

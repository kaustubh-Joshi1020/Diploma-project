package com.example.medicaluserapp;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.medicaluserapp.files.login2;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class loginupload extends AppCompatActivity {
    EditText name;
    EditText gender;
    EditText mobilenumber;
    EditText dob;
    EditText email;
    EditText address;
    EditText bloodgroup;
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginupload);

        Bundle b1 = getIntent().getExtras();
        final String Userid = b1.getString("USERID");

        name = (EditText)findViewById(R.id.name);
        gender = (EditText)findViewById(R.id.gender);
        mobilenumber = (EditText)findViewById(R.id.mobilenumber);
        dob = (EditText)findViewById(R.id.dateofbirth);
        email = (EditText)findViewById(R.id.email);
        address = (EditText)findViewById(R.id.address);
        bloodgroup = (EditText)findViewById(R.id.bloodgroup);
        submit = (Button) findViewById(R.id.submit);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // EditText[] All = new EditText[]{name, gender, mobilenumber, dob, email, address, bloodgroup};
               // String[] Message = new String[]{"Enter the name", "Enter the gender", "Enter the mobilenumber", "Enter the dateofbirth", "Enter the email", "Enter the address", "enter the bloodgroup"};
               // String[] Validation = new String[]{"NONE", "NONE", "NONE", "NONE", "NONE", "NONE", "NONE"};
               // String[] Vmessage = new String[]{"NO", "NO", "NO", "NO", "NO", "NO", "NO"};
               // if (CheckHandler.checkAll(All, Message, Validation, Vmessage)) {
                    login2 l = new login2();
                    l.setName(name.getText().toString());
                    l.setGender(gender.getText().toString());
                    l.setMobilenumber(mobilenumber.getText().toString());
                    l.setDateofbirth(dob.getText().toString());
                    l.setEmail(email.getText().toString());
                    l.setAddress(address.getText().toString());
                    l.setBloodgroup(bloodgroup.getText().toString());
                    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("PROFILE");
                    databaseReference.child(Userid).setValue(l);
                    Toast toast = Toast.makeText(loginupload.this,"successfull form",Toast.LENGTH_SHORT);
                    toast.show();

               // }
                //else {
                  //  Toast toast = Toast.makeText(loginupload.this,"Unsuccessfull form",Toast.LENGTH_SHORT);
                    //toast.show();
                //}
            }
        });
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("PROFILE").child(Userid);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override

            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    address.setText(dataSnapshot.child("address").getValue(String.class));
                    name.setText(dataSnapshot.child("name").getValue(String.class));
                    gender.setText(dataSnapshot.child("gender").getValue(String.class));
                    dob.setText(dataSnapshot.child("dateofbirth").getValue(String.class));
                    mobilenumber.setText(dataSnapshot.child("mobilenumber").getValue(String.class));
                    bloodgroup.setText(dataSnapshot.child("bloodgroup").getValue(String.class));
                    email.setText(dataSnapshot.child("email").getValue(String.class));





                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }



        });
    }
}

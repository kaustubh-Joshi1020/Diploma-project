package com.example.medicaluserapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.medicaluserapp.files.registestrationupload;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class registration extends AppCompatActivity {

    EditText name ;
    EditText userid;
    EditText password;
    EditText email;
    Button register;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        name = (EditText)findViewById(R.id.name);
        userid = (EditText)findViewById(R.id.userid);
        password = (EditText)findViewById(R.id.password);
        email = (EditText)findViewById(R.id.email);
        register = (Button)findViewById(R.id.register);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                registestrationupload r = new registestrationupload();
                r.setEmail(email.getText().toString());
                r.setUserid(userid.getText().toString());
                r.setName(name.getText().toString());
                r.setPassword(password.getText().toString());
                DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("REGISTRATION");
                databaseReference.child(userid.getText().toString()).setValue(r);
                Toast toast = Toast.makeText(registration.this,"Registration Successful",Toast.LENGTH_SHORT);
                toast.show();
            }
        });


    }
}

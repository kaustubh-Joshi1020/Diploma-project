package com.example.medicaldoctorapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.EventListener;

public class doctorlogin extends AppCompatActivity {
    EditText userid;
    EditText password;
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctorlogin);
        userid = (EditText)findViewById(R.id.userid);
        password = (EditText)findViewById(R.id.password);
        submit = (Button)findViewById(R.id.SUBMIT);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("REGISTRATION_DOCTOR").child(userid.getText().toString());
                databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.child("password").exists())
                        {
                            String pass = dataSnapshot.child("password").getValue(String.class);
                            if (pass.equals(password.getText().toString()))
                            {
                                 Intent intent = new Intent(doctorlogin.this,Dashboard.class);
                                 intent.putExtra("USERID",userid.getText().toString());
                                 startActivity(intent);
                                Toast toast = Toast.makeText(doctorlogin.this,"Login Successfull",Toast.LENGTH_SHORT);
                                toast.show();


                            }
                            else {
                                Toast toast = Toast.makeText(doctorlogin.this,"Login Failed",Toast.LENGTH_SHORT);
                                toast.show();

                            }
                        }
                        else
                        {
                            Toast toast = Toast.makeText(doctorlogin.this,"Login Failed",Toast.LENGTH_SHORT);
                            toast.show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

            }
        });

    }
}

package com.example.medicaldoctorapp.ui.Total_Patient_List;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.medicaldoctorapp.R;
import com.example.medicaldoctorapp.patient.Doctor_Data;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Doctor_Fill_Details extends AppCompatActivity {
    TextView fill;
    EditText weight, diet, bodytemperature, bloodpressure;//PATIENT_ID;
    Button sub;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor__fill__details);
        Bundle b1 = getIntent().getExtras();
        final String patient_id = b1.getString("PATIENT_ID");
        //PATIENT_ID=(EditText)findViewById(R.id.patientid);
        fill = (TextView)findViewById(R.id.fill);
        weight = (EditText)findViewById(R.id.weight);
        diet = (EditText)findViewById(R.id.diet);
        bodytemperature = (EditText)findViewById(R.id.temperature);
        bloodpressure = (EditText)findViewById(R.id.bloodpressure);
        sub = (Button)findViewById(R.id.SUBMIT);

        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Doctor_Data dd = new Doctor_Data();
                dd.setWeight(weight.getText().toString());
               // dd.setPatientid(PATIENT_ID.getText().toString());
                dd.setDiet(diet.getText().toString());
                dd.setBodytemperature(bodytemperature.getText().toString());
                dd.setBloodpressure(bloodpressure.getText().toString());
                DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("DOCTORFILL").child(patient_id);
                databaseReference.setValue(dd);
                Toast.makeText(Doctor_Fill_Details.this, "Data Submitted", Toast.LENGTH_SHORT).show();
            }
        });
      DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("PROFILE").child(patient_id);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                   // fill.setText(dataSnapshot.child("patientid").getValue(String.class));
                    fill.setText("Name : "+dataSnapshot.child("name").getValue(String.class));
                    fill.setText(fill.getText().toString()+"\nAddress : "+dataSnapshot.child("address").getValue(String.class));
                    fill.setText(fill.getText().toString()+"\nBloodgroup : "+dataSnapshot.child("bloodgroup").getValue(String.class));
                    fill.setText(fill.getText().toString()+"\nDate Of Birth : "+dataSnapshot.child("dateofbirth").getValue(String.class));
                    fill.setText(fill.getText().toString()+"\nEmail ID : "+dataSnapshot.child("email").getValue(String.class));
                    fill.setText(fill.getText().toString()+"\nGender: "+dataSnapshot.child("gender").getValue(String.class));
                    fill.setText(fill.getText().toString()+"\nMobile : "+dataSnapshot.child("mobilenumber").getValue(String.class));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
}
